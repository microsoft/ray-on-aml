import os
import time
import subprocess
import threading
import socket
import sys, uuid
import platform
import mlflow
import ray
import inspect
from textwrap import dedent
from azureml.core import Workspace, Experiment, Environment, Datastore, Dataset, ScriptRunConfig
from azureml.core.runconfig import PyTorchConfiguration
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.core.environment import Environment
from azureml.core.conda_dependencies import CondaDependencies

def flush(proc, proc_log):
    while True:
        proc_out = proc.stdout.readline()
        if proc_out == "" and proc.poll() is not None:
            proc_log.close()
            break
        elif proc_out:
            sys.stdout.write(proc_out)
            proc_log.write(proc_out)
            proc_log.flush()
def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP
def startRayMaster():
    conda_env_name = sys.executable.split('/')[-3]
    print(conda_env_name)
    #set the the python to this conda env

    cmd =f'. $CONDA_PREFIX/etc/profile.d/conda.sh && conda activate {conda_env_name} && ray stop && ray start --head --port=6379 --object-manager-port=8076'
    try:
        #if this is not the default environment, it will run
        subprocess.check_output(cmd, shell=True)
    except:
#         User runs this in default environment, just goahead without activating
        cmd ='ray stop && ray start --head --port=6379 --object-manager-port=8076'
        subprocess.check_output(cmd, shell=True)
    ip = get_ip()
    return ip
def startRay(master_ip=None):
    ip = get_ip()
    print("- env: MASTER_ADDR: ", os.environ.get("MASTER_ADDR"))
    print("- env: MASTER_PORT: ", os.environ.get("MASTER_PORT"))
    print("- env: RANK: ", os.environ.get("RANK"))
    print("- env: LOCAL_RANK: ", os.environ.get("LOCAL_RANK"))
    print("- env: NODE_RANK: ", os.environ.get("NODE_RANK"))
    rank = os.environ.get("RANK")
    
    master = os.environ.get("MASTER_ADDR")
    print("- my rank is ", rank)
    print("- my ip is ", ip)
    print("- master is ", master)
    if not os.path.exists("logs"):
        os.makedirs("logs")

    print("free disk space on /tmp")
    os.system(f"df -P /tmp")
#     if master_ip:
#         #this is worker process
#         cmd ='ray start --address=10.0.0.11:6379 --object-manager-port=8076'
    cmd = f"ray start --address={master_ip}:6379 --object-manager-port=8076"


    print(cmd)
#     scheduler_log = open("logs/scheduler_log.txt", "w")
#     scheduler_proc = subprocess.Popen(
#         cmd.split(),
#         stdout=subprocess.PIPE,
#         stderr=subprocess.STDOUT,
#         universal_newlines=True

#     )
    worker_log = open("logs/worker_{rank}_log.txt".format(rank=rank), "w")

    worker_proc = subprocess.Popen(
    cmd.split(),
    universal_newlines=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    )
    flush(worker_proc, worker_log)
#     scheduler_flush = threading.Thread(
#         target=flush, args=(scheduler_proc, scheduler_log)
#     )
#     scheduler_flush.start()
    time.sleep(1000000)
    

def getRay(ws, vnet_rg = None, compute_cluster = 'ray_on_aml', vm_size='STANDARD_DS3_V2',vnet='rayvnet', subnet='default', exp ='ray_on_aml', maxnode =5,
          additional_conda_packages=[],additional_pip_packages=[] ):
    #create or get the cluster with maxnode, then create an experiment to create ray cluster, get current ray and create ray init and return ray object
#     try:
#         #logic to check if ray cluster is already started and running, then return ray
        
#     except:
        #ray is not there, go ahead and create
    #start current node master
    master_ip = startRayMaster()
    # Verify that cluster does not exist already
    ws_detail = ws.get_details()
    ws_rg = ws_detail['id'].split("/")[4]
    try:
        ray_cluster = ComputeTarget(workspace=ws, name=compute_cluster)
        print('Found existing cluster, use it.')
        print("current directory ", os.listdir())
    except ComputeTargetException:
        if vnet_rg is None:
            vnet_rg = ws.ws_rg
        compute_config = AmlCompute.provisioning_configuration(vm_size=vm_size,
                                                            min_nodes=0, max_nodes=maxnode,
                                                            vnet_resourcegroup_name=vnet_rg,
                                                            vnet_name=vnet,
                                                            subnet_name=subnet)
        ray_cluster = ComputeTarget.create(ws, compute_cluster, compute_config)

        ray_cluster.wait_for_completion(show_output=True)


    python_version = ["python="+platform.python_version()]

    base_conda_dep =['gcsfs', 'fs-gcsfs', 'jupyterlab', 'jupyter-server-proxy', 'numpy', 'h5py', 'scipy', 'toolz', 
                     'bokeh', 'dask', 'distributed', 'notebook', 'matplotlib', 'pandas', 'pandas-datareader', 'pytables', 'snakeviz', 
                     'ujson', 'graphviz', 'fastparquet', 'dask-ml', 'adlfs', 'pytorch', 'torchvision', 'pip']
    base_pip_dep = ['python-snappy', 'fastparquet', 'azureml-mlflow', 'ray[default]', 'xgboost_ray', 'raydp', 'xgboost', 'pyarrow==4.0.1']

    conda_packages = python_version+additional_conda_packages +base_conda_dep
    pip_packages = base_pip_dep +additional_pip_packages

    rayEnv = Environment(name="rayEnv")

    conda_dep = CondaDependencies()

    for conda_package in conda_packages:
        conda_dep.add_conda_package(conda_package)

    for pip_package in pip_packages:
        conda_dep.add_pip_package(pip_package)

    # Adds dependencies to PythonSection of myenv
    rayEnv.python.conda_dependencies=conda_dep
    rayEnv.python.conda_dependencies.serialize_to_string()
    
    ##Create the source file
    os.makedirs(".tmp", exist_ok=True)
    source_file_content = """
    import os
    import time
    import subprocess
    import threading
    import socket
    import sys, uuid
    import platform
    import mlflow
    import ray
    def flush(proc, proc_log):
        while True:
            proc_out = proc.stdout.readline()
            if proc_out == "" and proc.poll() is not None:
                proc_log.close()
                break
            elif proc_out:
                sys.stdout.write(proc_out)
                proc_log.write(proc_out)
                proc_log.flush()

    def startRay(master_ip=None):
        ip = socket.gethostbyname(socket.gethostname())
        print("- env: MASTER_ADDR: ", os.environ.get("MASTER_ADDR"))
        print("- env: MASTER_PORT: ", os.environ.get("MASTER_PORT"))
        print("- env: RANK: ", os.environ.get("RANK"))
        print("- env: LOCAL_RANK: ", os.environ.get("LOCAL_RANK"))
        print("- env: NODE_RANK: ", os.environ.get("NODE_RANK"))
        rank = os.environ.get("RANK")

        master = os.environ.get("MASTER_ADDR")
        print("- my rank is ", rank)
        print("- my ip is ", ip)
        print("- master is ", master)
        if not os.path.exists("logs"):
            os.makedirs("logs")

        print("free disk space on /tmp")
        os.system(f"df -P /tmp")
        cmd = f"ray start --address={master_ip}:6379 --object-manager-port=8076"
        worker_log = open("logs/worker_{rank}_log.txt".format(rank=rank), "w")

        worker_proc = subprocess.Popen(
        cmd.split(),
        universal_newlines=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        )
        flush(worker_proc, worker_log)

        time.sleep(1000000)

    if __name__ == "__main__":
        parser = argparse.ArgumentParser()
        parser.add_argument("--master_ip")
        args, unparsed = parser.parse_known_args()
        master_ip = args.master_ip
        startRay(master_ip)

    """


    source_file = open(".tmp/source_file.py", "w")
    n = source_file.write(dedent(source_file_content))
    source_file.close()
    src = ScriptRunConfig(source_directory='.tmp',
                       script='source_file.py',
                       environment=rayEnv,
                       compute_target=ray_cluster,
                       distributed_job_config=PyTorchConfiguration(node_count=maxnode),
                          arguments = ["--master_ip",master_ip]
                       )
#     src = ScriptRunConfig(source_directory='./source',
#                        script='ray_on_aml.py',
#                        environment=rayEnv,
#                        compute_target=ray_cluster,
#                        distributed_job_config=PyTorchConfiguration(node_count=maxnode)                       )
    run = Experiment(ws, exp).submit(src)
    time.sleep(30)
    ray.init(address="auto",ignore_reinit_error=True)
    return run, ray
    
        
